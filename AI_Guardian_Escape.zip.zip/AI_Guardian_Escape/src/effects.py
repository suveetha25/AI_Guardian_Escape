"""
=========================================
AI Guardian Escape
effects.py

Visual Effects
-----------------------------------------
• Screen Fade
• Portal Glow
• Magic Aura
• Flash Effect
=========================================
"""

import math
import pygame

from settings import *


class FadeEffect:
    def __init__(self):
        self.alpha = 255
        self.speed = 8
        self.active = False
        self.fade_in = True

    # ----------------------------------
    def start_fade_in(self):
        self.alpha = 255
        self.fade_in = True
        self.active = True

    # ----------------------------------
    def start_fade_out(self):
        self.alpha = 0
        self.fade_in = False
        self.active = True

    # ----------------------------------
    def update(self):
        if not self.active:
            return

        if self.fade_in:
            self.alpha -= self.speed
            if self.alpha <= 0:
                self.alpha = 0
                self.active = False
        else:
            self.alpha += self.speed
            if self.alpha >= 255:
                self.alpha = 255
                self.active = False

    # ----------------------------------
    def draw(self, screen):
        if not self.active:
            return

        overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        overlay.fill((10, 8, 18, self.alpha))
        screen.blit(overlay, (0, 0))


# ==========================================================
# Portal Glow
# ==========================================================
class PortalGlow:
    def __init__(self):
        self.phase = 0.0

    def update(self):
        self.phase += 0.08

    def draw(self, screen, portal):
        cx, cy = portal.center
        glow = pygame.Surface((180, 180), pygame.SRCALPHA)

        pulse = math.sin(self.phase) * 5

        for radius, alpha in [(58, 18), (46, 32), (36, 48)]:
            pygame.draw.circle(
                glow,
                (110, 240, 255, alpha),
                (90, 90),
                int(radius + pulse)
            )

        screen.blit(glow, (cx - 90, cy - 90))

        ring_rect = portal.inflate(24, 18)
        pygame.draw.ellipse(screen, (220, 255, 255), ring_rect, 3)
        pygame.draw.ellipse(screen, (120, 245, 255), portal, 2)

        inner = portal.inflate(-10, -12)
        if inner.width > 4 and inner.height > 4:
            pygame.draw.arc(
                screen,
                WHITE,
                inner,
                self.phase,
                self.phase + 2.8,
                2
            )


# ==========================================================
# Magic Aura
# ==========================================================
class MagicAura:
    def __init__(self):
        self.phase = 0.0

    def update(self):
        self.phase += 0.12

    def draw(self, screen, player):
        cx, cy = player.rect.center
        aura = pygame.Surface((120, 120), pygame.SRCALPHA)

        pulse = math.sin(self.phase) * 4

        if player.has_shield:
            aura_colour = (255, 225, 120)
        elif player.is_invisible:
            aura_colour = (130, 255, 255)
        elif player.speed_timer > 0:
            aura_colour = (255, 210, 110)
        else:
            aura_colour = (195, 140, 255)

        for radius, alpha in [(26, 28), (20, 45), (15, 65)]:
            pygame.draw.circle(
                aura,
                (*aura_colour, alpha),
                (60, 60),
                int(radius + pulse)
            )

        screen.blit(aura, (cx - 60, cy - 60))


# ==========================================================
# Screen Flash
# ==========================================================
class FlashEffect:
    def __init__(self):
        self.alpha = 0

    def trigger(self):
        self.alpha = 180

    def update(self):
        if self.alpha > 0:
            self.alpha -= 8
            if self.alpha < 0:
                self.alpha = 0

    def draw(self, screen):
        if self.alpha <= 0:
            return

        flash = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        flash.fill((255, 255, 255, self.alpha))
        screen.blit(flash, (0, 0))