"""
=========================================
AI Guardian Escape
player.py

Player Class
=========================================
"""

import math
import pygame

from settings import *


class Player:
    def __init__(self):
        self.width = PLAYER_SIZE
        self.height = PLAYER_SIZE

        self.rect = pygame.Rect(
            60,
            HEIGHT // 2,
            self.width,
            self.height
        )

        self.color = PLAYER_COLOR

        self.walk_speed = PLAYER_SPEED
        self.run_speed = PLAYER_RUN_SPEED
        self.speed = self.walk_speed

        self.health = PLAYER_MAX_HEALTH
        self.score = 0
        self.inventory = []

        self.is_running = False
        self.is_invisible = False
        self.has_shield = False

        self.invisible_timer = 0
        self.speed_timer = 0

        self.anim_time = 0

    # =========================================
    # Reset Player
    # =========================================
    def reset(self):
        self.rect.x = 60
        self.rect.y = HEIGHT // 2

        self.health = PLAYER_MAX_HEALTH
        self.score = 0
        self.inventory.clear()

        self.is_running = False
        self.is_invisible = False
        self.has_shield = False

        self.invisible_timer = 0
        self.speed_timer = 0
        self.anim_time = 0

    # =========================================
    # Movement
    # =========================================
    def move(self, walls):
        keys = pygame.key.get_pressed()

        dx = 0
        dy = 0

        self.is_running = keys[pygame.K_LSHIFT] or keys[pygame.K_RSHIFT]

        if self.is_running:
            self.speed = self.run_speed
        else:
            self.speed = self.walk_speed

        if keys[pygame.K_w]:
            dy -= self.speed

        if keys[pygame.K_s]:
            dy += self.speed

        if keys[pygame.K_a]:
            dx -= self.speed

        if keys[pygame.K_d]:
            dx += self.speed

        self.rect.x += dx

        for wall in walls:
            if self.rect.colliderect(wall):
                if dx > 0:
                    self.rect.right = wall.left
                elif dx < 0:
                    self.rect.left = wall.right

        self.rect.y += dy

        for wall in walls:
            if self.rect.colliderect(wall):
                if dy > 0:
                    self.rect.bottom = wall.top
                elif dy < 0:
                    self.rect.top = wall.bottom

        if self.rect.left < 40:
            self.rect.left = 40

        if self.rect.right > WIDTH - 40:
            self.rect.right = WIDTH - 40

        if self.rect.top < 40:
            self.rect.top = 40

        if self.rect.bottom > HEIGHT - 40:
            self.rect.bottom = HEIGHT - 40

        if dx != 0 or dy != 0:
            self.anim_time += 0.25
        else:
            self.anim_time += 0.08

    # =========================================
    # Update Timers
    # =========================================
    def update(self):
        if self.invisible_timer > 0:
            self.invisible_timer -= 1
            self.is_invisible = True
        else:
            self.is_invisible = False

        if self.speed_timer > 0:
            self.speed_timer -= 1
            self.speed = self.run_speed + 2
        else:
            if not self.is_running:
                self.speed = self.walk_speed

    # =========================================
    # Powerups
    # =========================================
    def activate_speed(self):
        self.speed_timer = FPS * POWERUP_DURATION

    def activate_invisibility(self):
        self.invisible_timer = FPS * INVISIBILITY_TIME

    def activate_shield(self):
        self.has_shield = True

    # =========================================
    # Damage
    # =========================================
    def take_damage(self):
        if self.has_shield:
            self.has_shield = False
            return

        self.health -= 1

    # =========================================
    # Healing
    # =========================================
    def heal(self):
        if self.health < PLAYER_MAX_HEALTH:
            self.health += 1

    # =========================================
    # Score
    # =========================================
    def add_score(self, points):
        self.score += points

    # =========================================
    # Draw
    # =========================================
    def draw(self, screen):
        bob = int(math.sin(self.anim_time * 3) * 2)

        draw_rect = self.rect.copy()
        draw_rect.y += bob

        if self.is_invisible:
            alpha = 135
        else:
            alpha = 255

        surf = pygame.Surface((draw_rect.width + 20, draw_rect.height + 20), pygame.SRCALPHA)
        cx = surf.get_width() // 2
        cy = surf.get_height() // 2 + 2

        body_blue = (70, 130, 255, alpha)
        cape_blue = (35, 85, 190, alpha)
        skin = (255, 220, 185, alpha)
        outline = (20, 30, 60, alpha)
        boot = (85, 55, 45, alpha)
        gold = (255, 220, 90, alpha)

        shadow_rect = pygame.Rect(cx - 11, cy + 10, 22, 8)
        pygame.draw.ellipse(surf, (0, 0, 0, 55), shadow_rect)

        cape_points = [
            (cx - 10, cy - 1),
            (cx + 10, cy - 1),
            (cx + 7, cy + 12),
            (cx, cy + 16),
            (cx - 7, cy + 12)
        ]
        pygame.draw.polygon(surf, cape_blue, cape_points)

        pygame.draw.ellipse(surf, body_blue, (cx - 9, cy - 1, 18, 18))
        pygame.draw.ellipse(surf, outline, (cx - 9, cy - 1, 18, 18), 2)

        pygame.draw.circle(surf, skin, (cx, cy - 7), 7)
        pygame.draw.circle(surf, outline, (cx, cy - 7), 7, 2)

        pygame.draw.arc(surf, body_blue, (cx - 10, cy - 15, 20, 14), 3.4, 6.0, 3)

        pygame.draw.circle(surf, outline, (cx - 3, cy - 8), 1)
        pygame.draw.circle(surf, outline, (cx + 3, cy - 8), 1)
        pygame.draw.arc(surf, outline, (cx - 4, cy - 5, 8, 5), 0.1, 3.0, 1)

        pygame.draw.line(surf, outline, (cx - 5, cy + 3), (cx - 8, cy + 11), 2)
        pygame.draw.line(surf, outline, (cx + 5, cy + 3), (cx + 8, cy + 11), 2)

        foot_offset = int(math.sin(self.anim_time * 6) * 2) if self.is_running else 0
        pygame.draw.ellipse(surf, boot, (cx - 9, cy + 12 + foot_offset, 7, 4))
        pygame.draw.ellipse(surf, boot, (cx + 2, cy + 12 - foot_offset, 7, 4))

        if self.speed_timer > 0:
            pygame.draw.circle(surf, gold, (cx + 10, cy - 11), 3)
            pygame.draw.circle(surf, (255, 255, 255, alpha), (cx + 10, cy - 11), 3, 1)

        if self.has_shield:
            pygame.draw.circle(surf, (255, 225, 90, 100), (cx, cy), 20, 3)
            pygame.draw.circle(surf, (255, 245, 180, 70), (cx, cy), 24, 2)

        screen.blit(surf, (draw_rect.x - 10, draw_rect.y - 10))