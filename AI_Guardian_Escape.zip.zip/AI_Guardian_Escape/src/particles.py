"""
=========================================
AI Guardian Escape
particles.py

Particle System
-----------------------------------------
Provides:
• Generic particle objects
• ParticleSystem manager
• Ambient particle spawning
• Portal sparkle effect
• Player magic trail effect
=========================================
"""

import random
import pygame

from settings import *


class Particle:
    def __init__(self, x, y, vx, vy, size, colour, life):
        self.x = float(x)
        self.y = float(y)
        self.vx = float(vx)
        self.vy = float(vy)
        self.size = float(size)
        self.colour = colour
        self.life = int(life)
        self.max_life = int(life)

    def update(self):
        self.x += self.vx
        self.y += self.vy
        self.life -= 1

    def draw(self, screen):
        if self.life <= 0:
            return

        alpha = max(0, min(255, int(255 * (self.life / self.max_life))))
        surface_size = max(2, int(self.size * 4))

        particle_surface = pygame.Surface((surface_size, surface_size), pygame.SRCALPHA)
        pygame.draw.circle(
            particle_surface,
            (*self.colour, alpha),
            (surface_size // 2, surface_size // 2),
            max(1, int(self.size))
        )

        screen.blit(
            particle_surface,
            (int(self.x) - surface_size // 2, int(self.y) - surface_size // 2)
        )

    def is_dead(self):
        return self.life <= 0


class ParticleSystem:
    def __init__(self):
        self.particles = []

    # =====================================
    # Add Generic Particle
    # =====================================
    def add_particle(self, x, y, colour=WHITE, size=3, life=30, vx=0, vy=0):
        if len(self.particles) >= MAX_PARTICLES:
            return

        self.particles.append(
            Particle(x, y, vx, vy, size, colour, life)
        )

    # =====================================
    # Portal Effect
    # =====================================
    def emit_portal(self, portal_rect, count=3):
        for _ in range(count):
            x = random.randint(portal_rect.left, portal_rect.right)
            y = random.randint(portal_rect.top, portal_rect.bottom)

            self.add_particle(
                x=x,
                y=y,
                colour=CYAN,
                size=random.randint(2, 4),
                life=random.randint(20, 40),
                vx=random.uniform(-0.8, 0.8),
                vy=random.uniform(-1.5, -0.2)
            )

    # =====================================
    # Magic Aura / Invisibility Trail
    # =====================================
    def emit_magic(self, player_rect, count=2):
        for _ in range(count):
            x = random.randint(player_rect.left, player_rect.right)
            y = random.randint(player_rect.top, player_rect.bottom)

            self.add_particle(
                x=x,
                y=y,
                colour=PURPLE,
                size=random.randint(2, 4),
                life=random.randint(18, 32),
                vx=random.uniform(-0.6, 0.6),
                vy=random.uniform(-0.8, 0.2)
            )

    # =====================================
    # Ambient Level Particles
    # =====================================
    def emit_ambient(self, level_number, count=1):
        colour = WHITE

        if level_number == FOREST:
            colour = LIGHT_GREY
        elif level_number == CASTLE:
            colour = CYAN
        elif level_number == SNOW:
            colour = WHITE
        elif level_number == VOLCANO:
            colour = ORANGE

        for _ in range(count):
            self.add_particle(
                x=random.randint(0, WIDTH),
                y=random.randint(0, HEIGHT),
                colour=colour,
                size=random.randint(1, 3),
                life=random.randint(25, 60),
                vx=random.uniform(-0.3, 0.3),
                vy=random.uniform(-0.4, 0.4)
            )

    # =====================================
    # Clear All
    # =====================================
    def clear(self):
        self.particles.clear()

    # =====================================
    # Update All
    # =====================================
    def update(self):
        for particle in self.particles:
            particle.update()

        self.particles = [p for p in self.particles if not p.is_dead()]

    # =====================================
    # Draw All
    # =====================================
    def draw(self, screen):
        for particle in self.particles:
            particle.draw(screen)